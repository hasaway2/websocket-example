package com.example.demo.controller;

import java.security.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.security.access.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;

import com.example.demo.entity.*;
import com.example.demo.websocket.*;

@Controller
public class SampleController {
	@Autowired
	private WebSocketService webSocketService;
	
	@GetMapping("/")
	public ModelAndView index() {
		return new ModelAndView("/index");
	}
	
	@GetMapping("/login")
	public void login() {
	}
	
	@Secured("ROLE_USER")
	@GetMapping("/write")
	public void write() {
	}
	
	@Secured("ROLE_USER")
	@PostMapping("/write")
	public ModelAndView write(Memo memo, Principal principal) {
		webSocketService.send(principal.getName(), memo.getReceiver(), "야 밥먹으러 가자");
		return new ModelAndView("redirect:/");
	}
	
	@GetMapping("/memo/unread")
	public ResponseEntity<?> unread(Principal principal) {
		if(principal!=null)
			return ResponseEntity.ok(3);
		return ResponseEntity.status(HttpStatus.CONFLICT).body("로그인이 필요합니다");
	}
}
