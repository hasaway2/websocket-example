package com.example.demo.dto;

import lombok.*;

@Data
@AllArgsConstructor
public class WebSocketResponse {
	private String sender;
	private String content;
}
