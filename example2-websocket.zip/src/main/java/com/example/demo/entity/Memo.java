package com.example.demo.entity;

import lombok.*;

@Data
public class Memo {
	private String receiver;
	private String message;
}
