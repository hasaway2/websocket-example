package com.example.demo.websocket;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.web.socket.*;
import org.springframework.web.socket.handler.*;

@Component
public class MessageWebSocketHandler extends TextWebSocketHandler {
	// 웹소켓 연결을 처리할 서비스 클래스 DI
	@Autowired
	private WebSocketService service;

	// 웹소켓 접속 요청이 들어왔을 때
	@Override
	public void afterConnectionEstablished(WebSocketSession session) throws Exception {
		service.addWebSocketUserOrAddSession(session);
	}

	// 웹소켓 연결이 끊어졌을 때(페이지 리로딩, 페이지 이동....등등)
	@Override
	public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
		service.removeSessionOrRemoveWebSocketUser(session);
	}
}
