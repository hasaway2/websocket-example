package com.example.demo.websocket;

import java.util.*;

import org.springframework.stereotype.*;
import org.springframework.web.socket.*;

import com.example.demo.dto.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;

@Component
public class WebSocketService {
	// 사용자는 하나가 아니라 여러개의 탭을 열 수 있고, 탭마다 웹소켓 연결이 필요하다
	// 한 사용자에 대한 웹 소켓을 처리할 WebSocketUser 객체 : 아이디와 웹소켓 세션의 Vector로 구성
	
	// WebSocketUser 객체들의 집합
	private List<WebSocketUser> users = new Vector<>();
	
	// Vector에서 사용자를 검색하는 함수
	private Integer findUserPosition(String username) {
		for(int i=0; i<users.size(); i++) {
			if(users.get(i).getUsername().equals(username))
				return i;
		}
		return -1;
	}
	
	// 새로운 세션이 만들어지면 -> users에서 WSUser를 찾아서 존재하지 않으면 WSUser 생성, 존재하면 세션만 추가 
	public void addWebSocketUserOrAddSession(WebSocketSession session) {
		String loginId = session.getPrincipal().getName();
		int position = findUserPosition(loginId);
		if(position==-1)
			users.add(new WebSocketUser(loginId, session));
		else
			users.get(position).add(session);
	}
	
	// 세션이 끊어지면
	// - users에서 WSUser를 찾은 다음 웹소켓 연결 숫자를 확인
	// - 연결 숫자가 1개면 WSUser 자체를 삭제, 2이상이면 연결만 삭제
	public void removeSessionOrRemoveWebSocketUser(WebSocketSession session) {
		int position = findUserPosition(session.getPrincipal().getName());
		if(position>=0) {
			if(users.get(position).getSessionCount()==1) 
				users.remove(position);
			else
				users.get(position).delete(session);
		}
	}
	
	// users에서 WSUser를 찾아 웹소켓을 통해 메시지를 보내는 메소드
	public void send(String sender, String receiver, String content) {
		WebSocketResponse response = new WebSocketResponse(sender, content);
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			 String json = objectMapper.writeValueAsString(response);
			 int position = findUserPosition(receiver);
			 users.get(position).sendMessage(json);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
	}
}
