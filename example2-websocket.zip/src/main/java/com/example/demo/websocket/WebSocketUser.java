package com.example.demo.websocket;

import java.io.*;
import java.util.*;

import org.springframework.web.socket.*;

import lombok.*;

//사용자 아이디, WebSocketSession의 리스트
@Data
public class WebSocketUser {
	private String username;
	private List<WebSocketSession> list = new Vector<>();
	
	// 생성자 : 새로운 사용자가 접속했을 때 아이디와 웹소켓 세션을 가지고 객체 생성
	public WebSocketUser(String username, WebSocketSession session) {
		this.username = username;
		this.list.add(session);
	}
	
	// 기존 사용자의 웹소켓 세션 추가
	public void add(WebSocketSession session) {
		this.list.add(session);
	}
	
	//  기존 사용자의 웹소켓 세션 삭제
	public void delete(WebSocketSession session) {
		this.list.remove(session);
	}

	// 사용자의 모든 웹소켓 세션으로 메시지 보낸다
	public void sendMessage(String msg) {
		TextMessage message = new TextMessage(msg);
		list.forEach(session->{
			try {
				session.sendMessage(message);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}

	public int getSessionCount() {
		return list.size();
	}
}
