$(document).ready(function() {
	let websocket;
		
	// 웹소켓 연결이 없다면 새로 만들어라
	if(websocket==undefined) {
		websocket = new WebSocket("ws://localhost:8081/websocket");
		
		// websocket 객체가 메시지를 수신했을 때 실행되는 이벤트 핸들러
		// websocket 객체가 jQuery 객체가 아니라 바닐라 JS 객체이므로 바닐라 문법을 사용
		websocket.onmessage = function (e) {
			// 웹소켓으로 수신한 데이터는 이벤트 객체의 data 속성에 들어있다 
			const message = JSON.parse(e.data);
			toastr.options={"progressBar": true};
			toastr.success(message.content, message.sender + "님의 메시지");
		}
		console.log(websocket);
	}
});